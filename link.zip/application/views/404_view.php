<?php
//Just a formality
//Can I name this page "Easter egg" lol?
//Vladislav Villevald thanks you
echo "404 NotFound";
?>